This is the README file for automation package of WinSCP.

For use of WinSCP automation package see
http://winscp.net/eng/docs/library
http://winscp.net/eng/docs/library_install

To use this package you must unpack it to the WinSCP installation folder
or to a folder, where you have already unpacked the WinSCP standalone package.
http://winscp.net/eng/docs/installation or
http://winscp.net/eng/docs/portable

To use the WinSCP assembly via COM interop, register it using:
%WINDIR%\Microsoft.NET\Framework\<version>\RegAsm.exe WinSCPnet.dll /codebase /tlb
where <version> is typically either v4.0.30319 or v2.0.50727.
http://winscp.net/eng/docs/library_install#registering

WinSCP homepage is http://winscp.net/

See the file 'license-dotnet.txt' for the license conditions.